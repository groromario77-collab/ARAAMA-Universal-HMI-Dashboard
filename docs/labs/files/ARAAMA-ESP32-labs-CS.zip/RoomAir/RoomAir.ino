// ESP32 Dev Module. Sériový port USB: 115200 baudů. Místní broker MQTT 3.1.1.
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <math.h>

const char WIFI_NAME[] = "";      // Název sítě Wi-Fi 2,4 GHz
const char WIFI_PASSWORD[] = "";  // Heslo k Wi-Fi
const char MQTT_HOST[] = "";      // Název nebo IP adresa místního brokeru
const char MQTT_USER[] = "";      // Uživatel brokeru (volitelné)
const char MQTT_PASSWORD[] = "";  // Heslo k brokeru (volitelné)
const uint16_t MQTT_PORT = 1883;
const char TOPIC[] = "lab/room-air/state";
const uint32_t PERIOD_MS = 5000;
const int DATA_PIN = 18;
DHT sensor(DATA_PIN, DHT22);

WiFiClient network;
PubSubClient mqtt(network);
char clientId[40];
uint32_t lastConnect = 0;
uint32_t lastSample = 0;

void setup() {
  Serial.begin(115200);
  sensor.begin();
  if (*WIFI_NAME && *MQTT_HOST) {
    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(true);
    WiFi.begin(WIFI_NAME, WIFI_PASSWORD);
    mqtt.setServer(MQTT_HOST, MQTT_PORT);
    snprintf(clientId, sizeof(clientId), "RoomAir-%012llX",
             (unsigned long long)ESP.getEfuseMac());
  }
}

void loop() {
  const uint32_t now = millis();
  if (*MQTT_HOST && WiFi.status() == WL_CONNECTED) {
    if (!mqtt.connected() && now - lastConnect >= PERIOD_MS) {
      lastConnect = now;
      mqtt.connect(clientId, *MQTT_USER ? MQTT_USER : nullptr,
                   *MQTT_USER ? MQTT_PASSWORD : nullptr);
    }
    mqtt.loop();
  }
  if (now - lastSample < PERIOD_MS) return;
  lastSample = now;

  float temperature = sensor.readTemperature();
  float humidity = sensor.readHumidity();
  if (!isfinite(temperature) || !isfinite(humidity)) {
    Serial.println("Čtení DHT22 selhalo");
    return;
  }
  char payload[96];
  snprintf(payload, sizeof(payload),
           "{\"temperature_c\":%.1f,\"humidity_pct\":%.1f}",
           temperature, humidity);
  Serial.println(payload);
  if (mqtt.connected() && !mqtt.publish(TOPIC, payload, false))
    Serial.println("Odeslání zprávy MQTT selhalo");
}
