"""Příklad: python simulate.py room --host localhost (mosquitto_pub musí být v PATH)."""
import argparse
import sys
import json
import math
import shutil
import subprocess
import time

def sample(project, seconds):
    if project == "room":
        return {"temperature_c": round(22 + 1.2 * math.sin(seconds / 150), 1),
                "humidity_pct": round(48 - 4 * math.sin(seconds / 150 - 0.4), 1)}
    return {"temperature_c": round(18.6 + 0.5 * math.sin(seconds / 220), 1),
            "pressure_hpa": round(1008 + 2 * math.sin(seconds / 280), 1)}

def main():
    parser = argparse.ArgumentParser(description="Každých 5 sekund odešle simulované hodnoty čidla ESP32.")
    parser.add_argument("project", choices=["room", "barometer"])
    parser.add_argument("--host", help="Adresa místního brokeru MQTT. Bez této volby se JSON vypíše do terminálu.")
    parser.add_argument("--port", type=int, default=1883)
    parser.add_argument("--count", type=int, help="Po tomto počtu zpráv skončit.")
    args = parser.parse_args()
    topic = "lab/" + ("room-air" if args.project == "room" else "window-pressure") + "/state"
    publisher = shutil.which("mosquitto_pub") or shutil.which("mosquitto_pub.exe")
    if args.host and not publisher:
        parser.error("Nainstalujte klienty Mosquitto a přidejte mosquitto_pub do PATH.")
    index = 0
    try:
        while args.count is None or index < args.count:
            payload = json.dumps(sample(args.project, index * 5), separators=(",", ":"))
            print(topic, payload, flush=True)
            if args.host:
                # mosquitto_pub může načíst přihlašovací údaje z vlastního konfiguračního souboru.
                subprocess.run([publisher, "-h", args.host, "-p", str(args.port),
                                "-t", topic, "-m", payload], check=True)
            index += 1
            if args.count is None or index < args.count:
                time.sleep(5)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    if not sys.stdout.isatty():
        sys.stdout.reconfigure(encoding="utf-8")
    if not sys.stderr.isatty():
        sys.stderr.reconfigure(encoding="utf-8")
    main()
