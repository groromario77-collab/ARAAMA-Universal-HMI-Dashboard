"""Example: python simulate.py room --host localhost (requires mosquitto_pub on PATH)."""
import argparse
import json
import math
import shutil
import subprocess
import time

def sample(project, seconds):
    if project == "room":
        return {"temperature_c": round(22 + 1.2 * math.sin(seconds / 150), 1),
                "humidity_pct": round(48 - 4 * math.sin(seconds / 150 - 0.4), 1)}
    return {"temperature_c": round(18.6 + 0.5 * math.sin(seconds / 220), 1),
            "pressure_hpa": round(1008 + 2 * math.sin(seconds / 280), 1)}

def main():
    parser = argparse.ArgumentParser(description="Publish synthetic ESP32 readings every 5 seconds.")
    parser.add_argument("project", choices=["room", "barometer"])
    parser.add_argument("--host", help="Local MQTT broker; omit to print JSON only.")
    parser.add_argument("--port", type=int, default=1883)
    parser.add_argument("--count", type=int, help="Stop after this many messages.")
    args = parser.parse_args()
    topic = "lab/" + ("room-air" if args.project == "room" else "window-pressure") + "/state"
    publisher = shutil.which("mosquitto_pub") or shutil.which("mosquitto_pub.exe")
    if args.host and not publisher:
        parser.error("Install the Mosquitto clients and add mosquitto_pub to PATH.")
    index = 0
    try:
        while args.count is None or index < args.count:
            payload = json.dumps(sample(args.project, index * 5), separators=(",", ":"))
            print(topic, payload, flush=True)
            if args.host:
                # mosquitto_pub can read private credentials from its own config file.
                subprocess.run([publisher, "-h", args.host, "-p", str(args.port),
                                "-t", topic, "-m", payload], check=True)
            index += 1
            if args.count is None or index < args.count:
                time.sleep(5)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
