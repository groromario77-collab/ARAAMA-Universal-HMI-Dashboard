// ESP32 Dev Module. USB Serial: 115200 baud. Broker: local MQTT 3.1.1.
#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_BMP280.h>
#include <math.h>

const char WIFI_NAME[] = "";      // Your 2.4 GHz network name
const char WIFI_PASSWORD[] = "";  // Your Wi-Fi password
const char MQTT_HOST[] = "";      // Your local broker's hostname or IP
const char MQTT_USER[] = "";      // Optional local broker user
const char MQTT_PASSWORD[] = "";  // Optional local broker password
const uint16_t MQTT_PORT = 1883;
const char TOPIC[] = "lab/window-pressure/state";
const uint32_t PERIOD_MS = 5000;
const int SDA_PIN = 21;
const int SCL_PIN = 22;
Adafruit_BMP280 sensor;
bool sensorReady = false;

WiFiClient network;
PubSubClient mqtt(network);
char clientId[40];
uint32_t lastConnect = 0;
uint32_t lastSample = 0;

void setup() {
  Serial.begin(115200);
  Wire.begin(SDA_PIN, SCL_PIN);
  if (*WIFI_NAME && *MQTT_HOST) {
    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(true);
    WiFi.begin(WIFI_NAME, WIFI_PASSWORD);
    mqtt.setServer(MQTT_HOST, MQTT_PORT);
    snprintf(clientId, sizeof(clientId), "WindowPressure-%012llX",
             (unsigned long long)ESP.getEfuseMac());
  }
}

void loop() {
  const uint32_t now = millis();
  if (*MQTT_HOST && WiFi.status() == WL_CONNECTED) {
    if (!mqtt.connected() && now - lastConnect >= PERIOD_MS) {
      lastConnect = now;
      mqtt.connect(clientId, *MQTT_USER ? MQTT_USER : nullptr,
                   *MQTT_USER ? MQTT_PASSWORD : nullptr);
    }
    mqtt.loop();
  }
  if (now - lastSample < PERIOD_MS) return;
  lastSample = now;

  if (!sensorReady) {
    sensorReady = sensor.begin(0x76) || sensor.begin(0x77);
    if (!sensorReady) {
      Serial.println("BMP280 missing at 0x76 and 0x77");
      return;
    }
  }
  float temperature = sensor.readTemperature();
  float pressure = sensor.readPressure() / 100.0f;  // Pa to hPa
  if (!isfinite(temperature) || !isfinite(pressure) || pressure <= 0) {
    sensorReady = false;
    Serial.println("BMP280 read failed");
    return;
  }
  char payload[96];
  snprintf(payload, sizeof(payload),
           "{\"temperature_c\":%.1f,\"pressure_hpa\":%.1f}",
           temperature, pressure);
  Serial.println(payload);
  if (mqtt.connected() && !mqtt.publish(TOPIC, payload, false))
    Serial.println("Publish failed");
}
