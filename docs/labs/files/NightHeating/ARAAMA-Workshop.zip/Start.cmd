@echo off
setlocal
pushd "%~dp0"
where py >nul 2>&1
if errorlevel 1 goto use_python
py -3 simulator.py --lan
goto done
:use_python
python simulator.py --lan
:done
popd
pause
