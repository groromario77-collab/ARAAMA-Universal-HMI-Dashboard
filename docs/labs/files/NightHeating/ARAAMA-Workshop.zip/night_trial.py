"""Two identical rooms, one night, no external dependencies. Units: h, kW, kWh, °C."""
from functools import lru_cache


FLOOR_CAPACITY = 1.10  # kWh/K
ROOM_CAPACITY = 0.38   # air, furniture and interior surfaces together, kWh/K
FLOOR_TO_ROOM = 0.18   # kW/K
ROOM_TO_OUTSIDE = 0.06 # kW/K
OUTSIDE = 4.0
FLOOR_TARGET = 26.0
HEATER_KW = 2.4
ROOM_START = (FLOOR_TO_ROOM * FLOOR_TARGET + ROOM_TO_OUTSIDE * OUTSIDE) / (FLOOR_TO_ROOM + ROOM_TO_OUTSIDE)
OPEN_MINUTE = 9 * 60   # start at 22:00, open at 07:00


def clock_at(minute):
    hours, minutes = divmod((22 * 60 + minute) % 1440, 60)
    return f'{hours:02}:{minutes:02}'


def simulate_room(heat_from):
    floor, room, kwh = FLOOR_TARGET, ROOM_START, 0.0
    ready_at = None
    opening = None
    for minute in range(1441):
        if minute >= heat_from and ready_at is None and floor >= 25.5 and room >= 20:
            ready_at = minute
        if minute == OPEN_MINUTE:
            opening = (floor, room, kwh)
        if minute == 1440:
            break
        transfer = FLOOR_TO_ROOM * (floor - room)
        losses = ROOM_TO_OUTSIDE * (room - OUTSIDE)
        # Supply full power during recovery, then just enough to hold the slab.
        demand = (FLOOR_TARGET - floor) * FLOOR_CAPACITY * 60 + transfer
        power = min(HEATER_KW, max(0.0, demand)) if minute >= heat_from else 0.0
        floor += (power - transfer) / (60 * FLOOR_CAPACITY)
        room += (transfer - losses) / (60 * ROOM_CAPACITY)
        kwh += power / 60
    return dict(open_floor=round(opening[0], 1), open_air=round(opening[1], 1),
                open_kwh=round(opening[2], 2), day_kwh=round(kwh, 2),
                end_floor=round(floor, 2), end_air=round(room, 2),
                storage_deficit=(FLOOR_TARGET-floor)*FLOOR_CAPACITY+(ROOM_START-room)*ROOM_CAPACITY,
                ready_at=ready_at)


@lru_cache(maxsize=19)
def night_trial(lead_hours):
    restart = OPEN_MINUTE - int(lead_hours * 60)
    hold = simulate_room(0)
    pause = simulate_room(restart)
    late = max(0, pause['ready_at'] - OPEN_MINUTE)
    return dict(lead=lead_hours, restart=clock_at(restart), hold=hold, pause=pause,
                ready=clock_at(pause['ready_at']), late_minutes=late,
                saving=round(hold['day_kwh']-pause['day_kwh'], 2),
                ready_message=('К открытию готово' if not late else 'Готово в '+clock_at(pause['ready_at'])))
