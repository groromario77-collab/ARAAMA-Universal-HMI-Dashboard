"""Virtual workshop for ARAAMA. Python 3.9+ standard library."""
import argparse
import copy
import ipaddress
import json
import math
import re
import socket
import time
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Lock
from night_trial import OUTSIDE, night_trial
from scene import render_scene


START = datetime(2026, 1, 5, 7, 0)  # Monday on the model's clock.
WEEK = ('Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс')
INITIAL_SCHEDULE = dict(enabled=True, mode='schedule', start='07:30', end='19:00',
                        days=list(range(1, 8)), time_basis='controller-local')
OUTLETS = {'iron': 80, 'dryer': 450}  # Watts at 230 V, equivalent resistive loads.
PANEL = Path(__file__).with_name('Мастерская.json')


def check_schedule(data):
    if not isinstance(data, dict) or set(data) != set(INITIAL_SCHEDULE):
        raise ValueError('Expected an ARAAMA schedule')
    if type(data['enabled']) is not bool or data['mode'] != 'schedule' or data['time_basis'] != 'controller-local':
        raise ValueError('Invalid schedule mode')
    days = data['days']
    if not isinstance(days, list) or not days or not all(type(d) is int and 1 <= d <= 7 for d in days) or len(set(days)) != len(days):
        raise ValueError('Use distinct weekdays 1..7')
    for t in (data['start'], data['end']):
        if t is not None and (not isinstance(t, str) or not re.fullmatch(r'(?:[01][0-9]|2[0-3]):[0-5][0-9]', t)):
            raise ValueError('Use HH:MM')
    if data['start'] == data['end']:
        raise ValueError('Start and end must differ')
    return {**data, 'days': sorted(days)}


def light_at(moment, schedule, previous):
    if not schedule['enabled']:
        return False
    start, end, days = schedule['start'], schedule['end'], schedule['days']
    now, day = moment.strftime('%H:%M'), moment.isoweekday()
    if start is None or end is None:
        if day in days and now == (start or end):
            return start is not None
        return previous
    if start < end:
        return day in days and start <= now < end
    return (day in days and now >= start) or ((day - 2) % 7 + 1 in days and now < end)


class Workshop:
    def __init__(self):
        self.clock = START
        self.floor = 21.0
        self.target = 24.0
        self.heating = True
        self.schedule = copy.deepcopy(INITIAL_SCHEDULE)
        self.light = light_at(self.clock, self.schedule, False)
        self.outlets = {'iron': True, 'dryer': False}
        self.energy = dict.fromkeys(OUTLETS, 0.0)
        self.preheat_hours = 2.0

    def voltage(self):
        phase = (self.clock - START).total_seconds() / 420
        return 230 + 1.4 * math.sin(phase)

    def thermostat(self):
        if self.floor <= self.target - 0.3:
            self.heating = True
        elif self.floor >= self.target + 0.3:
            self.heating = False

    def advance(self, seconds):
        while seconds > 0:
            step = min(10, seconds)
            self.thermostat()
            equilibrium = 34 if self.heating else 19
            self.floor = equilibrium + (self.floor - equilibrium) * math.exp(-step / 2700)
            voltage = self.voltage()
            for key, watts in OUTLETS.items():
                if self.outlets[key]:
                    self.energy[key] += watts * (voltage / 230) ** 2 * step / 3600000
            self.clock += timedelta(seconds=step)
            self.light = light_at(self.clock, self.schedule, self.light)
            seconds -= step
        self.thermostat()

    def state(self):
        volts = self.voltage()
        sockets = {}
        for key, rated in OUTLETS.items():
            power = rated * (volts / 230) ** 2 if self.outlets[key] else 0
            sockets[key] = dict(on=self.outlets[key], volts=round(volts, 1),
                                amps=round(power / volts, 3), watts=round(power, 1),
                                kwh=round(self.energy[key], 4))
        return dict(clock=f'{WEEK[self.clock.weekday()]} {self.clock:%H:%M}',
                    floor_c=round(self.floor, 1), target_c=self.target, heating=self.heating,
                    light=self.light, outlets=sockets, night=night_trial(self.preheat_hours))

    def apply(self, name, value):
        if name in OUTLETS:
            if type(value) is not bool:
                raise ValueError('Use true or false')
            self.outlets[name] = value
        elif name == 'target':
            if type(value) not in (float, int) or not 18 <= value <= 30 or value * 2 != int(value * 2):
                raise ValueError('Use 18..30 in steps of 0.5')
            self.target = float(value)
            self.thermostat()
        elif name == 'preheat':
            if type(value) not in (int, float) or not 0 <= value <= 9 or value * 2 != int(value * 2):
                raise ValueError('Use 0..9 hours in steps of 0.5')
            self.preheat_hours = float(value)
        elif name == 'schedule':
            self.schedule = check_schedule(value)
            self.light = light_at(self.clock, self.schedule, self.light)
        else:
            raise KeyError(name)


class Server(ThreadingHTTPServer):
    def __init__(self, address, speed):
        self.model = Workshop()
        self.speed = speed
        self.lock = Lock()
        self.started = None
        self.elapsed = 0
        super().__init__(address, Handler)

    def update(self):
        now = time.monotonic()
        if self.started is None:
            self.started = now
        elapsed = int((now - self.started) * self.speed)
        self.model.advance(elapsed - self.elapsed)
        self.elapsed = elapsed


class Handler(BaseHTTPRequestHandler):
    timeout = 10

    def send_json(self, status, obj, attachment=False):
        data = json.dumps(obj, ensure_ascii=False, allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(data)))
        if attachment:
            self.send_header('Content-Disposition', 'attachment; filename="Workshop-ARAAMA.json"')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == '/night-scene.png':
            with self.server.lock:
                trial = night_trial(self.server.model.preheat_hours)
            data = render_scene(trial['pause']['open_air'], trial['pause']['open_floor'],
                                OUTSIDE, trial['restart'], trial['ready'],trial['pause']['day_kwh'])
            self.send_response(200)
            self.send_header('Content-Type','image/png')
            self.send_header('Content-Length',str(len(data)))
            self.send_header('Cache-Control','no-store')
            self.end_headers()
            self.wfile.write(data)
            return
        if self.path in ('/panel.json','/phone.json','/tablet.json'):
            host = self.headers.get('Host', '').partition(':')[0]
            if host != 'localhost':
                try:
                    host = str(ipaddress.IPv4Address(host))
                except ValueError:
                    return self.send_json(400, {'error': 'Open this link using the IPv4 address of this computer'})
            panel = json.loads(PANEL.read_text(encoding='utf-8'))
            panel['connections'][0]['url'] = f'http://{host}:{self.server.server_port}'
            phone = self.path == '/phone.json' or (self.path == '/panel.json'
                    and 'mobile' in self.headers.get('User-Agent','').lower())
            if phone:
                night = next(pg for pg in panel['pages'] if pg['id']=='night')
                for card in night['widgets']:
                    if card['id']=='room-cutaway':
                        card['h']=7
                    else:
                        card['y']-=5
            return self.send_json(200, panel, attachment=True)
        if self.path not in ('/state', '/schedule'):
            return self.send_json(404, {'endpoints': ['/panel.json', '/state', '/schedule']})
        with self.server.lock:
            self.server.update()
            payload = self.server.model.state() if self.path == '/state' else copy.deepcopy(self.server.model.schedule)
        self.send_json(200, payload)

    def do_POST(self):
        if self.path not in ('/set/iron', '/set/dryer', '/set/target', '/set/schedule', '/set/preheat'):
            return self.send_json(404, {'error': 'Unknown command'})
        if self.headers.get_content_type() != 'application/json':
            return self.send_json(415, {'error': 'Expected JSON'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 4096:
                raise ValueError('Invalid body size')
            value = json.loads(self.rfile.read(length))
            with self.server.lock:
                self.server.update()
                self.server.model.apply(self.path.split('/')[-1], value)
                payload = self.server.model.state()
            self.send_json(200, payload)
        except (ValueError, UnicodeError) as exc:
            self.send_json(400, {'error': str(exc)})

    def log_request(self, code='-', size='-'):
        if self.command == 'POST' or code != 200:
            super().log_request(code, size)


def choose_lan_address():
    addresses = sorted({row[4][0] for row in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)
                        if not ipaddress.IPv4Address(row[4][0]).is_loopback
                        and not ipaddress.IPv4Address(row[4][0]).is_link_local})
    if len(addresses) == 1:
        return addresses[0]
    print('Choose the IPv4 address of the adapter on the same network as your tablet:')
    for index, address in enumerate(addresses, 1):
        print(f'  {index}. {address}')
    answer = input('Number or local IPv4 address: ').strip()
    if answer.isdecimal() and 1 <= int(answer) <= len(addresses):
        return addresses[int(answer) - 1]
    return str(ipaddress.IPv4Address(answer))


def main():
    parser = argparse.ArgumentParser(description='ARAAMA virtual workshop (local HTTP)')
    network = parser.add_mutually_exclusive_group()
    network.add_argument('--bind', default='127.0.0.1', help='IPv4 address of the computer')
    network.add_argument('--lan', action='store_true', help='Choose a LAN adapter for a tablet')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--speed', type=int, choices=range(1, 601), metavar='1..600', default=30)
    args = parser.parse_args()
    try:
        host = choose_lan_address() if args.lan else args.bind
        with Server((host, args.port), args.speed) as server:
            print(f'Workshop x{args.speed} | Mon 07:00', flush=True)
            print(f'Open on tablet: http://{host}:{server.server_port}/panel.json', flush=True)
            print(f'View readings:  http://{host}:{server.server_port}/state', flush=True)
            print('Ctrl+C to stop. The model starts when the first readings are requested.', flush=True)
            server.serve_forever()
    except KeyboardInterrupt:
        pass
    except (OSError, ValueError) as exc:
        parser.exit(1, f'Cannot start the server: {exc}\n')


if __name__ == '__main__':
    main()
