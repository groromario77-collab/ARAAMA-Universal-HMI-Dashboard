"""Composite current sensor readings onto their positions in the illustrated workshop."""
import json
import struct
import zlib
from functools import lru_cache
from pathlib import Path
from zipfile import ZipFile


@lru_cache(maxsize=1)
def artwork():
    with ZipFile(Path(__file__).with_name('scene-art.zip')) as data:
        return (json.loads(data.read('layout.json')), data.read('background.indices'),
                data.read('numerals.alpha'), data.read('palette.rgb'))


def png_chunk(kind, data):
    return struct.pack('>I',len(data)) + kind + data + struct.pack('>I',zlib.crc32(kind+data))


def temperature(value):
    return f'{value:g}'.replace('.', ',').replace('-', '−') + ' °C'


@lru_cache(maxsize=19)
def render_scene(air, floor, outside, restart, ready, day_kwh):
    layout, background, masks, palette = artwork()
    canvas = bytearray(background)
    width, height = layout['width'], layout['height']
    values = dict(air=temperature(air),floor=temperature(floor),outside=('+' if outside>0 else '')+temperature(outside),
                  restart=restart,ready=ready,energy=f'{day_kwh:.2f}'.replace('.',','))
    for key, value in values.items():
        x, y = layout['slots'][key]
        for ch in value:
            left,top,w,h,advance,offset = layout['glyphs'][ch]
            for dy in range(h):
                target = (y+layout['baseline']+top+dy)*width+x+left
                for dx,alpha in enumerate(masks[offset+dy*w:offset+(dy+1)*w]):
                    if alpha:
                        canvas[target+dx] = 224 + round(alpha*31/255)
            x += advance
    scanlines = b''.join(b'\x00'+canvas[i:i+width] for i in range(0,len(canvas),width))
    header = struct.pack('>IIBBBBB',width,height,8,3,0,0,0)
    return (b'\x89PNG\r\n\x1a\n' + png_chunk(b'IHDR',header)
            + png_chunk(b'PLTE',palette) + png_chunk(b'IDAT',zlib.compress(scanlines,6))
            + png_chunk(b'IEND',b''))
