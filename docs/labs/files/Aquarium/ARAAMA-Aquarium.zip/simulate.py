"""Aquarium telemetry demo. Run: python simulate.py --count 1"""
import argparse
import json
import shutil
import subprocess
import time

TOPIC = "lab/aquarium/state"
PERIOD_SECONDS = 5


def readings():
    """Accelerated thermal cycle for observing hysteresis; no actuator output."""
    water = 25.52
    rate = 0.0015
    heater = True
    while True:
        if water >= 25.6:
            heater = False
        elif water <= 25.2:
            heater = True
        yield {"water_temperature_c": round(water, 2), "heater_on": int(heater)}
        target_rate = 0.0015 if heater else -0.0007
        rate += 0.22 * (target_rate - rate)
        water += PERIOD_SECONDS * rate


def main():
    parser = argparse.ArgumentParser(description="Generate aquarium telemetry every five seconds.")
    parser.add_argument("--host", help="Local MQTT broker address. Omit to print readings only.")
    parser.add_argument("--port", type=int, default=1883)
    parser.add_argument("--count", type=int, help="Stop after this many messages.")
    args = parser.parse_args()
    if args.count is not None and args.count < 1:
        parser.error("--count must be positive")
    publish = shutil.which("mosquitto_pub")
    if args.host and not publish:
        parser.error("Install Mosquitto clients and add mosquitto_pub to PATH.")
    try:
        for index, value in enumerate(readings(), start=1):
            payload = json.dumps(value, separators=(",", ":"))
            print(TOPIC, payload, flush=True)
            if args.host:
                subprocess.run([publish, "-h", args.host, "-p", str(args.port),
                                "-t", TOPIC, "-m", payload], check=True)
            if index == args.count:
                break
            time.sleep(PERIOD_SECONDS)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
