"""Simulace akvária. Spuštění: python simulate.py --count 1"""
import argparse
import sys
import json
import shutil
import subprocess
import time

TOPIC = "lab/aquarium/state"
PERIOD_SECONDS = 5


def readings():
    """Zrychlený teplotní cyklus pro pozorování hystereze bez ovládání skutečného topení."""
    water = 25.52
    rate = 0.0015
    heater = True
    while True:
        if water >= 25.6:
            heater = False
        elif water <= 25.2:
            heater = True
        yield {"water_temperature_c": round(water, 2), "heater_on": int(heater)}
        target_rate = 0.0015 if heater else -0.0007
        rate += 0.22 * (target_rate - rate)
        water += PERIOD_SECONDS * rate


def main():
    parser = argparse.ArgumentParser(description="Každých pět sekund vygeneruje teplotu vody a stav topení.")
    parser.add_argument("--host", help="Adresa místního brokeru MQTT. Bez této volby se hodnoty vypíší do terminálu.")
    parser.add_argument("--port", type=int, default=1883)
    parser.add_argument("--count", type=int, help="Po tomto počtu zpráv skončit.")
    args = parser.parse_args()
    if args.count is not None and args.count < 1:
        parser.error("--count musí být kladné číslo")
    publish = shutil.which("mosquitto_pub")
    if args.host and not publish:
        parser.error("Nainstalujte klienty Mosquitto a přidejte mosquitto_pub do PATH.")
    try:
        for index, value in enumerate(readings(), start=1):
            payload = json.dumps(value, separators=(",", ":"))
            print(TOPIC, payload, flush=True)
            if args.host:
                subprocess.run([publish, "-h", args.host, "-p", str(args.port),
                                "-t", TOPIC, "-m", payload], check=True)
            if index == args.count:
                break
            time.sleep(PERIOD_SECONDS)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    if not sys.stdout.isatty():
        sys.stdout.reconfigure(encoding="utf-8")
    if not sys.stderr.isatty():
        sys.stderr.reconfigure(encoding="utf-8")
    main()
